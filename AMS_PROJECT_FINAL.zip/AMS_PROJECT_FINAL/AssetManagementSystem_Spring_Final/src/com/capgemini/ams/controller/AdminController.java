package com.capgemini.ams.controller;



import java.time.LocalDate;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.capgemini.ams.bean.Asset;
import com.capgemini.ams.exception.AssetException;
import com.capgemini.ams.service.IAMSService;
import com.capgemini.ams.service.IAdminService;

@Controller
public class AdminController extends MultiActionController{
	
	@Autowired
	IAdminService adminService;
	
	@Autowired
	IAMSService amsService;
	
	@Autowired
	Asset asset;
	
	String url = null;
	String errorMessage = null;
	String successMessage = null;

	/**
	 * This method is used to transfer page to success page if asset allocated to manager successfully
	 * or to an error page if there is an error allocating asset. 
	 * @param requestId
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/approve")
	public String allocateAsset(@RequestParam("requestId") long requestId,Model model)
	{	
		boolean flag = false;
		url = null;
		
		try {
			flag = adminService.allocateAsset(requestId,LocalDate.now());
			
			if(flag)
			{
				successMessage = "Asset"+asset.getAssetName()+" is allocated successfully "
						+ "to RequestId "+requestId;
				
				model.addAttribute("message",successMessage);
				
				System.out.println("Success page");
				url = "success";
			}
			
		} catch (AssetException e) {
			
			errorMessage = e.getMessage();
			model.addAttribute("message",errorMessage);
			url = "error";
		}
		
		return url;
	}
	
	/** This method is used to transfer page to Add asset form i.e. 
	
	 * @param model - It is storing asset object.
	 * @return
	 */
	@RequestMapping(value="/addAsset")
	public String addAsset(Model model)
	{
		url = null;
		
		asset = new Asset();
		model.addAttribute("asset", asset);
		
		url = "AddAsset";
		
		return url;
	}

	
	/** This method is use to add a new asset .if asset added successfully then it will
	 * transfer to success page else to an error page.
	 * @param asset
	 * @param bindingResult - Binding Result is used for validation.
	 * @param model - It is storing asset object.
	 * @return
	 */
	@RequestMapping(value="/addNewAsset")
	public String addedAsset(@ModelAttribute("asset")@Valid Asset asset, BindingResult bindingResult, Model model) {
		url = null;
		boolean isAssetAdded = false;
		
		if(bindingResult.hasErrors())
		{
			System.out.println("in validation");
			/*asset = new Asset();*/
			model.addAttribute("asset", asset);
			url = "AddAsset";
		}
		else
		{	
		try 
			{	
				isAssetAdded = adminService.addAsset(asset);
				if(isAssetAdded)
				{
					successMessage = "Asset added successfully with asset name "+asset.getAssetName()+"asset id "+asset.getAssetId();
					model.addAttribute("message",successMessage);
					url = "success";
				}
			} 
			catch (AssetException e)
			{
				errorMessage = e.getMessage();
				model.addAttribute("message",errorMessage);
				url = "error";
			}
			
		}	
		return url;
	}

	/**This method is used to transfer request to success page if report
	 * generated successfully else to an error page.
	 * @param model - It is storing success message which is displayed 
	 * at success page.
	 * @return
	 */
	@RequestMapping(value="/generateReport")
	public String generateReport(Model model)
	{
		url = null;
		
		boolean flag = false;
		try 
		{
			flag = adminService.generateReport();
			if(flag)
			{
				successMessage = "Asset allocation report is generated successfully";
				model.addAttribute("message",successMessage);
				url = "success";
			}
		} 
		catch (AssetException e) 
		{

			errorMessage = e.getMessage();
			model.addAttribute("message",errorMessage);
			url = "error";
		}
		return url;
	}
	
	/**This method is used to transfer request to modify page else to an 
	 * error page if there is an error modifying it . 
	 * @param assetId It stores asset id. 
	 * @param model  It is storing asset object.
	 * @return
	 */
	@RequestMapping(value="/modifyAsset")
	public String requestToRaise(@RequestParam("assetId") long assetId, Model model)
	{
		url = null;
		try {
			asset=amsService.getAssetDetailsById(assetId);
			
			asset.setAssetId(asset.getAssetId());	// Sets assetId to asset
			asset.setAssetName(asset.getAssetName());
			asset.setAssetDes(asset.getAssetDes());
			asset.setQuantity(asset.getQuantity());
			
			model.addAttribute("asset", asset);
			
			url = "Modify";
			
		}
		catch (AssetException e) 
		{
			errorMessage = e.getMessage();
			model.addAttribute("message",errorMessage);
			url = "error";
		}
		return url;
	}

	/**If asset is modified successfully then it will transmit request to success page else to 
	 * an error page .
	 * @param assetId
	 * @param asset
	 * @param bindingResult
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/modifyAssetById")
	public String raiseRequest(@RequestParam("assetId") long assetId, @ModelAttribute("asset")@Valid Asset asset,BindingResult bindingResult, Model model)
	{
		try
		{
			boolean flag = adminService.modifyAsset(asset);
			url = null;
			
			if(flag)
			{
				successMessage = "Asset "+asset.getAssetName()+" is modified successfully";
				model.addAttribute("message",successMessage);
				url = "success";
			}
		}
		catch (AssetException e) 
		{
			errorMessage = e.getMessage();
			model.addAttribute("message",errorMessage);
			url = "error";
		}
		
		return url;
	}
}



	

