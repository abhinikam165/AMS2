package com.capgemini.ams.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.ams.bean.UserMaster;
import com.capgemini.ams.exception.AssetException;
import com.capgemini.ams.service.IAuthenticationService;

@Controller
public class AuthenticationController{

	@Autowired
	UserMaster user;
	
	@Autowired
	IAuthenticationService authService;
	
	String url = null;
	String errorMessage = null;
	String successMessage = null;
	
	/**This method will transfer request to login page.
	 * @param model It stores object of user.
	 * @return
	 */
	@RequestMapping("/login")
	public String goToLogin(Model model) {
		
		model.addAttribute("user", user);
		return "Login";
	}
	
	/**This method will Validate username and password, If username and password provided are wrong
	 * it will redirect to same login page or else to admin or manager page according to user type.
	 * @param user
	 * @param bindingResult It is used for  input validation.
	 * @param model It stores object of user.
	 * @return
	 */
	@RequestMapping("/validateUser")
	public String validateUser(@ModelAttribute("user")@Valid UserMaster user, BindingResult bindingResult, Model model) 
	{
		boolean flag=false;
		
		if(bindingResult.hasErrors())
		{
			model.addAttribute("user", user);
			url = "Login";
		}
		else
		{
			try 
			{
				flag=authService.validateUser(user);
			}
			catch (AssetException e)
			{
			
				errorMessage = e.getMessage();
				model.addAttribute("message",errorMessage);
			}
			if(flag)
			{
				String userName=user.getUsername();
				String password=user.getUserpassword();
				try {
					String userType=authService.getUserType(userName, password);
					
					if(userType.equals("Admin"))
					{
						url = "AdminOperations";
					}
					else
					{
						url = "ManagerOperations";
					}	
					
				} 
				catch (AssetException e) 
				{
					errorMessage=e.getMessage();
					model.addAttribute("errorMessage", errorMessage);
				}
			}
			else
			{
				model.addAttribute("user", user);
				url = "Login";
			}
		}
		return url;
	}

	/** On successfully logout ,Page will transfer to index page from where we can
	 * login again.
	 * @return
	 */
	@RequestMapping("/logout")
	public String logout()
	{
		return "index";	
	}

}
