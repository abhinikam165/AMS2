package com.capgemini.ams.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.ams.bean.Asset;
import com.capgemini.ams.bean.AssetRequest;
import com.capgemini.ams.bean.Employee;
import com.capgemini.ams.exception.AssetException;
import com.capgemini.ams.service.IAMSService;
import com.capgemini.ams.service.IManagerService;

@Controller
public class ManagerController {
	
	@Autowired
	IAMSService amsService;
	
	@Autowired
	AssetRequest assetRequest;
	
	@Autowired
	IManagerService managerService;
	
	String url = null;
	String errorMessage = null;
	String successMessage = null;

	
	@Autowired
	Asset asset;
	/**This method will transfer page to Raise request page to raise a request.
	 * @param assetId It will fetch asset id parameter and stores it in assetId.
	 * @param model - It stores object of assetRequest.
	 * @return
	 */
	@RequestMapping(value="/requestToRaise")
	public String requestToRaise(@RequestParam("assetId") long assetId, Model model)
	{
		try {
			asset=amsService.getAssetDetailsById(assetId);
			
			assetRequest.setAsset(asset);		// Sets assetId to assetyRequest
			assetRequest.setAssetname(asset.getAssetName());
			assetRequest.setAssetdes(asset.getAssetDes());
			Employee emp = new Employee();
			emp.setMgrcode(100002);

			assetRequest.setQuantity(null);
			model.addAttribute("assetRequest", assetRequest);
			url = "raiseRequest";
			
		} catch (AssetException e) 
		{
			errorMessage=e.getMessage();
			model.addAttribute("errorMessage", errorMessage);
		}
		return url;
	}

	/**On successful raising of request,it will redirect to success page .	
	 * @param assetRequest-It fetches assetRequest parameter and stores it in assetRequest.
	 * @param model - It stores object of requestId.
	 * @return
	 */
	@RequestMapping(value="/raiseRequestId")
	public String raiseRequest(@ModelAttribute("assetRequest") AssetRequest assetRequest, Model model)
	{
		try {
			assetRequest.setStatus("Allocated");
			long requestId = managerService.raiseRequest(assetRequest);
			model.addAttribute("requestId",requestId);
			
			successMessage = "Asset allocation report is generated successfully";
			model.addAttribute("message",successMessage);
			url = "success";
			
		} catch (AssetException e) 
		{
			errorMessage=e.getMessage();
			model.addAttribute("errorMessage", errorMessage);
			url = "error";
					
		}
		return url;
	}
	
}
