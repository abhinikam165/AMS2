package com.capgemini.ams.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.ams.bean.AssetRequest;
import com.capgemini.ams.dao.IManagerDAO;
import com.capgemini.ams.dao.ManagerDAOImpl;
import com.capgemini.ams.exception.AssetException;

@Service
@Transactional
public class ManagerServiceImpl implements IManagerService
{
	@Autowired
	IManagerDAO managerDAO;
	
	public void setDao(ManagerDAOImpl managerDao) 
	{
		this.managerDAO = managerDao; 
	}
	
	public ManagerServiceImpl()
	{
		managerDAO = new ManagerDAOImpl();
	}
	
	@Override
	public long raiseRequest(AssetRequest assetRequest) throws AssetException
	{
		return managerDAO.raiseRequest(assetRequest);
	}
}
