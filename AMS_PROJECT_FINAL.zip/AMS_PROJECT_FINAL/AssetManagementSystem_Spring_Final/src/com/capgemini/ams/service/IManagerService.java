package com.capgemini.ams.service;

import com.capgemini.ams.bean.AssetRequest;
import com.capgemini.ams.exception.AssetException;

public interface IManagerService 
{
	public long raiseRequest(AssetRequest assetRequest) throws AssetException;
}
