package com.capgemini.ams.service;
import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.ams.bean.Asset;
import com.capgemini.ams.dao.AdminDAOImpl;
import com.capgemini.ams.dao.IAdminDAO;
import com.capgemini.ams.exception.AssetException;

@Service
@Transactional
public class AdminServiceImpl implements IAdminService 
{
	@Autowired
	IAdminDAO adminDao;
	
	public AdminServiceImpl()
	{
		adminDao = new AdminDAOImpl();
	}
	
	public void setDao(AdminDAOImpl adminDao)
	{
		this.adminDao = adminDao;
	}

	@Override
	public boolean addAsset(Asset asset) throws AssetException 
	{
		return adminDao.addAsset(asset);
	}

	@Override
	public boolean allocateAsset(long requestId, LocalDate releaseDate) throws AssetException
	{
		return adminDao.allocateAsset(requestId,releaseDate);
	}

	@Override
	public boolean generateReport() throws AssetException 
	{
		return adminDao.generateReport();
	}

	@Override
	public boolean modifyAsset(Asset asset) throws AssetException
	{
		return adminDao.modifyAsset(asset);
	}
}
