package com.capgemini.ams.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.ams.bean.Asset;
import com.capgemini.ams.bean.AssetRequest;
import com.capgemini.ams.dao.AMSDaoImpl;
import com.capgemini.ams.dao.IAMSDao;
import com.capgemini.ams.exception.AssetException;

@Service
@Transactional
public class AMSServiceImpl implements IAMSService
{
	@Autowired
	IAMSDao amsDao;
	
	public void setDao(IAMSDao amsDao) 
	{
		this.amsDao = amsDao;
	}
	
	public AMSServiceImpl()
	{
		amsDao  = new AMSDaoImpl();
	}
	
	@Override
	public ArrayList<Asset> showAllAssets() throws AssetException
	{
		return amsDao.showAllAssets();
	}

	@Override
	public ArrayList<AssetRequest> showAllRequests() throws AssetException 
	{
		return amsDao.showAllRequests();
	}

	@Override
	public Asset getAssetDetailsById(long assetId) throws AssetException 
	{
		return amsDao.getAssetDetailsById(assetId);
	}
}
