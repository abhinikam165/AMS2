package com.capgemini.ams.service;

import java.util.ArrayList;

import com.capgemini.ams.bean.Asset;
import com.capgemini.ams.bean.AssetRequest;
import com.capgemini.ams.exception.AssetException;

public interface IAMSService 
{
	ArrayList<Asset> showAllAssets() throws AssetException;

	ArrayList<AssetRequest> showAllRequests()throws AssetException;

	Asset getAssetDetailsById(long assetId) throws AssetException;
}
