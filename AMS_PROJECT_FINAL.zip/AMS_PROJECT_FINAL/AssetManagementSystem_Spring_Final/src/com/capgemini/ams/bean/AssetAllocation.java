package com.capgemini.ams.bean;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.stereotype.Component;

import java.util.Date;


/**
 * The persistent class for the ASSETALLOCATION database table.
 * 
 */
@Entity
@Component
@NamedQuery(name="Assetallocation.findAll", query="SELECT a FROM AssetAllocation a")
public class AssetAllocation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="ASSETALLOCATION_ALLOCATIONID_GENERATOR", sequenceName="SEQ_ALLOCATIONID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ASSETALLOCATION_ALLOCATIONID_GENERATOR")
	private long allocationid;

	@Temporal(TemporalType.DATE)
	@Column(name="ALLOCATION_DATE")
	private Date allocationDate;

	@Temporal(TemporalType.DATE)
	@Column(name="RELEASE_DATE")
	private Date releaseDate;

	//bi-directional many-to-one association to Asset
	@ManyToOne
	@JoinColumn(name="ASSETID")
	private Asset asset;

	//bi-directional many-to-one association to Employee
	@ManyToOne
	@JoinColumn(name="EMPNUM")
	private Employee employee;

	public AssetAllocation() {
	}

	public long getAllocationid() {
		return this.allocationid;
	}

	public void setAllocationid(long allocationid) {
		this.allocationid = allocationid;
	}

	public Date getAllocationDate() {
		return this.allocationDate;
	}

	public void setAllocationDate(Date allocationDate) {
		this.allocationDate = allocationDate;
	}

	public Date getReleaseDate() {
		return this.releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

	public Asset getAsset() {
		return this.asset;
	}

	public void setAsset(Asset asset) {
		this.asset = asset;
	}

	public Employee getEmployee() {
		return this.employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

}