package com.capgemini.ams.bean;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the EMPLOYEE database table.
 * 
 */
@Entity
@Component
@NamedQuery(name="Employee.findAll", query="SELECT e FROM Employee e")
public class Employee implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="EMPLOYEE_EMPNUM_GENERATOR", sequenceName="SEQ_EMPNUM")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="EMPLOYEE_EMPNUM_GENERATOR")
	private long empnum;

	private String empname;

	@Temporal(TemporalType.DATE)
	private Date hiredate;

	private String job;

	private int mgrcode;

	//bi-directional many-to-one association to Assetallocation
	@OneToMany(mappedBy="employee")
	private List<AssetAllocation> assetallocations;

	//bi-directional many-to-one association to Assetrequest
	@OneToMany(mappedBy="employee1")
	private List<AssetRequest> assetrequests1;

	//bi-directional many-to-one association to Assetrequest
	@OneToMany(mappedBy="employee2")
	private List<AssetRequest> assetrequests2;

	//bi-directional many-to-one association to Department
	//One department can have multiple employees
	@ManyToOne
	@JoinColumn(name="DEPTID")
	private Department department;

	//bi-directional many-to-one association to UserMaster
	@OneToMany(mappedBy="employee")
	private List<UserMaster> userMasters;

	public Employee() {
	}

	public long getEmpnum() {
		return this.empnum;
	}

	public void setEmpnum(long empnum) {
		this.empnum = empnum;
	}

	public String getEmpname() {
		return this.empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public Date getHiredate() {
		return this.hiredate;
	}

	public void setHiredate(Date hiredate) {
		this.hiredate = hiredate;
	}

	public String getJob() {
		return this.job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public int getMgrcode() {
		return this.mgrcode;
	}

	public void setMgrcode(int i) {
		this.mgrcode = i;
	}

	public List<AssetAllocation> getAssetallocations() {
		return this.assetallocations;
	}

	public void setAssetallocations(List<AssetAllocation> assetallocations) {
		this.assetallocations = assetallocations;
	}

	public AssetAllocation addAssetallocation(AssetAllocation assetallocation) {
		getAssetallocations().add(assetallocation);
		assetallocation.setEmployee(this);

		return assetallocation;
	}

	public AssetAllocation removeAssetallocation(AssetAllocation assetallocation) {
		getAssetallocations().remove(assetallocation);
		assetallocation.setEmployee(null);

		return assetallocation;
	}

	public List<AssetRequest> getAssetrequests1() {
		return this.assetrequests1;
	}

	public void setAssetrequests1(List<AssetRequest> assetrequests1) {
		this.assetrequests1 = assetrequests1;
	}

	public AssetRequest addAssetrequests1(AssetRequest assetrequests1) {
		getAssetrequests1().add(assetrequests1);
		assetrequests1.setEmployee1(this);

		return assetrequests1;
	}

	public AssetRequest removeAssetrequests1(AssetRequest assetrequests1) {
		getAssetrequests1().remove(assetrequests1);
		assetrequests1.setEmployee1(null);

		return assetrequests1;
	}

	public List<AssetRequest> getAssetrequests2() {
		return this.assetrequests2;
	}

	public void setAssetrequests2(List<AssetRequest> assetrequests2) {
		this.assetrequests2 = assetrequests2;
	}

	public AssetRequest addAssetrequests2(AssetRequest assetrequests2) {
		getAssetrequests2().add(assetrequests2);
		assetrequests2.setEmployee2(this);

		return assetrequests2;
	}

	public AssetRequest removeAssetrequests2(AssetRequest assetrequests2) {
		getAssetrequests2().remove(assetrequests2);
		assetrequests2.setEmployee2(null);

		return assetrequests2;
	}

	public Department getDepartment() {
		return this.department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public List<UserMaster> getUserMasters() {
		return this.userMasters;
	}

	public void setUserMasters(List<UserMaster> userMasters) {
		this.userMasters = userMasters;
	}

	public UserMaster addUserMaster(UserMaster userMaster) {
		getUserMasters().add(userMaster);
		userMaster.setEmployee(this);

		return userMaster;
	}

	public UserMaster removeUserMaster(UserMaster userMaster) {
		getUserMasters().remove(userMaster);
		userMaster.setEmployee(null);

		return userMaster;
	}

}