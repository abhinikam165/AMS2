package com.capgemini.ams.testcase;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.capgemini.ams.dao.AuthenticationDAOImpl;
import com.capgemini.ams.exception.AssetException;
import com.capgemini.ams.service.AuthenticationServiceImpl;

public class AuthenticationTest {
	AuthenticationServiceImpl authService;
	AuthenticationDAOImpl authDao;

	@Before
	public void init() {
		authService = new AuthenticationServiceImpl();
		authDao = new AuthenticationDAOImpl();
		authService.setDao(authDao);
	}

	@Test
	public void testGetUserType() throws AssetException {
		assertEquals("Admin", authService.getUserType("Ayushi", "Ayushi12"));

	}

	@Test
	public void testGetUserTypeFail() throws AssetException {
		assertNotEquals("Manager",
				authService.getUserType("Ayushi", "Ayushi12"));

	}
}
