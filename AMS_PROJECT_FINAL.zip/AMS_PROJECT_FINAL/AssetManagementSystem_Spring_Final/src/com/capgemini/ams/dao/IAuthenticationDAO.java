package com.capgemini.ams.dao;

import com.capgemini.ams.bean.UserMaster;
import com.capgemini.ams.exception.AssetException;

public interface IAuthenticationDAO {

	/**
	 * Description : 
	 * 
	 * @param userName
	 * @param password
	 * @return
	 * @throws AssetException
	 */
	String getUserType(String userName, String password)throws AssetException;

	boolean validateUser(UserMaster user)throws AssetException;

}
