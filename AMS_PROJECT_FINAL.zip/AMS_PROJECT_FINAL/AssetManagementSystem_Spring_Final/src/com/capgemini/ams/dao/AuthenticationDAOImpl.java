package com.capgemini.ams.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.capgemini.ams.bean.UserMaster;
import com.capgemini.ams.exception.AssetException;

@Repository
public class AuthenticationDAOImpl implements IAuthenticationDAO{

	@PersistenceContext
	private EntityManager entityManager;
	
	Logger logger = Logger.getLogger(AdminDAOImpl.class);
	
	/* 
	 * This method will give usertype(Admin or Manager) according to username and password entered 
	 */
	@Override
	public String getUserType(String userName, String password)throws AssetException {	
		
		
		String str = "SELECT user FROM UserMaster user WHERE user.username=:userName AND user.userpassword=:password";
		TypedQuery<UserMaster> query = entityManager.createQuery(str, UserMaster.class);
		
		query.setParameter("userName", userName);
		query.setParameter("password", password);
		
		UserMaster obj= query.getSingleResult();
		String userType=obj.getUsertype();	
		return userType;
	}
	
	/* 
	 * Validate user will validate the credentials provided by admin or manager from database.
	 */
	@Override
	public boolean validateUser(UserMaster user) throws AssetException {

		boolean flag=false;
		
		String str = "SELECT user FROM UserMaster user WHERE user.username=:uname AND user.userpassword=:upass";
		TypedQuery<UserMaster> query = entityManager.createQuery(str,UserMaster.class);
		
		query.setParameter("uname", user.getUsername());
		query.setParameter("upass", user.getUserpassword());
		
		UserMaster obj = query.getSingleResult();
		
		if(obj != null)
		{
			if(user.getUsername().equals(obj.getUsername()))
			{
				if(user.getUserpassword().equals(obj.getUserpassword()))
				{
					flag = true;
					logger.info("Password validated successfully");
				}
				else
				{
					logger.error("Incorrect password");
					flag = false;
				}
			}
			else 
			{
				logger.error("Incorrect username");
				flag = false;
			}
		}
		else
		{
			throw new AssetException("No user found.");
		}
		
		return flag;
	}
}
